import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableComponentComponent } from './table-component/table-component.component';
import { HighlightDirective } from './directives/highlight.directive';



@NgModule({
  declarations: [TableComponentComponent,HighlightDirective],
  imports: [
    CommonModule
  ],
  exports:[
    TableComponentComponent
  ]
})
export class UserModule { }
