import { Component, OnInit } from '@angular/core';
import { User } from '../models/User.interface';

@Component({
  selector: 'app-table-component',
  templateUrl: './table-component.component.html',
  styleUrls: ['./table-component.component.scss']
})
export class TableComponentComponent implements OnInit {
  users:User[]=[
    {
      name:'Aditya',
      username:'aditya12',
      email:'aditya@gmail.com'
    },
    {
      name:'jagdeesh',
      username:'jagdeesh',
      email:'jagdeesh@gmail.com'
    },
    {
      name:'anil',
      username:'anil',
      email:'anil@gmail.com'
    },
    {
      name:'abinash',
      username:'abinash',
      email:'abinash@gmail.com'
    }
  ];
  constructor() { }
  handleDeleteRow(userIndex:number){
this.users.splice(userIndex,1);
}
  ngOnInit(): void {
  }

}
